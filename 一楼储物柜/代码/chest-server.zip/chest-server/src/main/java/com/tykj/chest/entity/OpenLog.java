package com.tykj.chest.entity;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@TableName("OpenLog")
public class OpenLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "OpenL_ID", type = IdType.AUTO)
    private Integer openlId;

    @TableField("Chest_ID")
    private Integer chestId;

    @TableField("User_ID")
    private Integer userId;

    @TableField("OpenL_OpenDate")
    private Date openlOpendate;

    @TableField("OpenL_UserName")
    private String openlUsername;

    @TableField("OpenL_UserType")
    private String openlUsertype;

    public Integer getOpenlId() {
        return openlId;
    }

    public void setOpenlId(Integer openlId) {
        this.openlId = openlId;
    }
    public Integer getChestId() {
        return chestId;
    }

    public void setChestId(Integer chestId) {
        this.chestId = chestId;
    }
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Date getOpenlOpendate() {
        return openlOpendate;
    }

    public void setOpenlOpendate(Date openlOpendate) {
        this.openlOpendate = openlOpendate;
    }
    public String getOpenlUsername() {
        return openlUsername;
    }

    public void setOpenlUsername(String openlUsername) {
        this.openlUsername = openlUsername;
    }
    public String getOpenlUsertype() {
        return openlUsertype;
    }

    public void setOpenlUsertype(String openlUsertype) {
        this.openlUsertype = openlUsertype;
    }

    @Override
    public String toString() {
        return "OpenLog{" +
        "openlId=" + openlId +
        ", chestId=" + chestId +
        ", userId=" + userId +
        ", openlOpendate=" + openlOpendate +
        ", openlUsername=" + openlUsername +
        ", openlUsertype=" + openlUsertype +
        "}";
    }
}
