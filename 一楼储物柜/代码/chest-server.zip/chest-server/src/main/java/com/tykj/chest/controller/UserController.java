package com.tykj.chest.controller;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.http.HttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.tykj.chest.config.CommonConfig;
import com.tykj.chest.config.Const;
import com.tykj.chest.entity.ChestInfo;
import com.tykj.chest.entity.UseLog;
import com.tykj.chest.mapper.ChestInfoMapper;
import com.tykj.chest.mapper.UseLogMapper;
import com.tykj.chest.service.IChestInfoService;
import com.tykj.chest.service.IOpenLogService;
import com.tykj.chest.utils.HttpClientUtil;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	IChestInfoService chestInfoService;
	
	@Autowired
	IOpenLogService openLogService;
	
	@Autowired
	UseLogMapper userLogMapper;
	
	@Autowired
	ChestInfoMapper chestInfoMapper;
	
	@Autowired
	CommonConfig commonConfig;
	
	/**
	 * 跳转用户主页  选择柜子
	 * @param session
	 * @param model
	 * @return
	 */
	@GetMapping("userSelectBox")
	public String userSelectBox(HttpSession session,Model model) {
		int userId = Integer.parseInt((String)session.getAttribute(Const.SESSION_USERID));//用户id
		
		List<ChestInfo> nullChestInfos = this.chestInfoMapper.getChestListByStatu(0);//空闲的柜子
		List<ChestInfo> useChestInfos = this.chestInfoService.getUseChestInfoList(userId);//占用中的柜子
		List<ChestInfo> myChestInfos = this.chestInfoMapper.getChestListByUserId(userId);//我的柜子
		model.addAttribute("nullChestInfos",nullChestInfos);
		model.addAttribute("useChestInfos",useChestInfos);
		model.addAttribute("myChestInfos",myChestInfos);
		return "UserShowChest";
	}
	
	/**
	 * 跳转用户申请柜子界面
	 * @param session
	 * @param model
	 * @return
	 */
	@GetMapping("/userApplyPage")
	public String userMainPage(HttpSession session,Model model,@RequestParam("chestId") Integer chestId) {
		int userId = Integer.parseInt((String)session.getAttribute(Const.SESSION_USERID));
		ChestInfo chestInfo = this.chestInfoService.getChestInfoById(chestId);
		if(chestInfo!=null && chestInfo.getChestState()) {
			return "redirect:/user/userSelectBox";
		}
//		if(userId != chestInfo.getUserId() || !chestInfo.getChestState()) {
//			return "redirect:/user/userSelectBox";
//		}
		model.addAttribute("chestId",chestId);
		model.addAttribute("chestSite",chestInfo.getChestSite());
		return "UserApply";
	}
	
	/** 跳转用户打开柜子界面
	 * @param session
	 * @param model
	 * @return
	 */
	@GetMapping("/userOpenPage")
	public String openBoxPage(HttpSession session,Model model,@RequestParam("chestId") Integer chestId) {
		ChestInfo chestInfo = chestInfoService.getChestInfoById(chestId);
		model.addAttribute("chestSite",chestInfo.getChestSite());
		model.addAttribute("chestRandom",chestInfo.getChestRandom());
		model.addAttribute("chestId",chestId);
		return "UserOpen";
	}
	
	@GetMapping("/userRecordPage")
	public String recordsPage(HttpSession session,Model model,@RequestParam("chestId") Integer chestId){
		int userId = Integer.parseInt((String)session.getAttribute(Const.SESSION_USERID));
		SimpleDateFormat dataf = new SimpleDateFormat("yyyy-MM-dd");
		String endDate = dataf.format(new Date());
		String startDate = dataf.format(new Date(System.currentTimeMillis()-1000*60*60*24*7));
		List<UseLog> logs = this.userLogMapper.getUserUseLogByDate(userId, startDate, endDate);
		model.addAttribute("User_Record",logs);
		model.addAttribute("chestId",chestId);
		return "UserRecord";
	}
	
	
	
	
	@ResponseBody
	@PostMapping("userApply")
	public Map<String,Object> UserApply(HttpSession session,Model model,@RequestParam("type") Integer type,@RequestParam("chestId") Integer chestId) {
		int userId = Integer.parseInt((String)session.getAttribute("User_ID"));
		String userName = (String)session.getAttribute("Oprt_Name");
		String userType = (String)session.getAttribute("User_Type");
		Object obj = session.getAttribute(Const.SESSION_LONGFUN_KEY);
		int canApplyCnt = (Integer)session.getAttribute(Const.SESSION_APPLYCOUNT);
		
		boolean islong = type ==1;
		if(islong) {//申请长期柜子
			boolean canApplyLong = false;//是否可申请长期柜子
			if(obj!=null) {
				canApplyLong = (Boolean)obj;
			}
			if(!canApplyLong) {//无权限申请
				Map<String,Object> result = new HashMap<>();
				result.put("successs", "1");
				result.put("message", "您没有权限申请长期柜子");
				return result;
			}
		}
		
		return this.chestInfoService.applyChest(chestId, canApplyCnt, userId, userName, userType, islong);
	}
	
	/**
	 * 通过随机码开柜
	 * @param session
	 * @param model
	 * @param chestRandom
	 * @return
	 */
	@ResponseBody
	@PostMapping("userOpen")
	public Map<String,Object> userOpen(HttpSession session,Model model,@RequestParam("chestRandom") Integer chestRandom) {
		
		Map<String,Object> map = new HashMap<>();
		int userId = Integer.parseInt((String)session.getAttribute("User_ID"));
		String userName = (String)session.getAttribute("Oprt_Name");
		String userType = (String)session.getAttribute("User_Type");
		ChestInfo chestInfo = chestInfoService.getChestInfoByRandom(chestRandom);
		if(chestInfo==null || !chestInfo.getChestState()) {
			map.put("success", "1");
			map.put("message", "该柜子已自动注销，请退出重新申请");
			return map;
		}
		if(userId != chestInfo.getUserId()) {
			map.put("success", "1");
			map.put("message", "该柜子不属于您");
			return map;
		}
		if(chestInfo.getLockstatu()) {
			map.put("success", "1");
			map.put("message", "该柜子已被锁定，请联系管理员");
			return map;
		}
		String url = "";
		if(chestInfo.getChestId() >=1 && chestInfo.getChestId() <= 72) {
			url = commonConfig.getResUrlS();
		}else {
			url = commonConfig.getResUrlN();
		}
		String p = "{'accountname':'tykj20180101','accountpwd':'tykj20180101','boxnumber':'" + chestInfo.getChestId() + "'}";
		byte[] bytes = null;
		try {
			bytes = p.getBytes("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		HttpEntity requestBody = new ByteArrayEntity(bytes);
		String responseStr = HttpClientUtil.getHttpPost(url, null, requestBody);
		JSONObject jsb = JSONObject.parseObject(responseStr);
		if(jsb != null) {
			String statuscode = jsb.getString("statuscode");
			if(statuscode!=null && statuscode.equals("1")) {
				openLogService.addOpenLog(chestInfo.getChestId(), userId, userName, userType);
				map.put("success", "0");
				map.put("message", "打开成功");
				return map;
			}else {
				map.put("success", "1");
				map.put("message", "打开失败");
				return map;
			}
		}else {
			map.put("success", "1");
			map.put("message", "打开失败");
			return map;
		}
		
		
	}
	
	@ResponseBody
	@PostMapping("/userlogOut")
	public Map<String,Object> userOut(HttpSession session,Model model,@RequestParam("chestId") Integer chestId) {
		Map<String,Object> result = new HashMap<>();
		ChestInfo chestInfo = chestInfoService.getChestInfoById(chestId);
		int userId = Integer.parseInt((String)session.getAttribute("User_ID"));
		if(chestInfo==null || !chestInfo.getChestState()) {//已经注销了
			result.put("success", "0");
			result.put("message", "已注销成功");
			return  result;
		}
		if(chestInfo.getUserId()!= userId) {
			result.put("success", "1");
			result.put("message", "该柜子不属于您");
			return  result;
		}
		
		if(chestInfoService.userRegistOut(chestId)) {
			result.put("success", "0");
			result.put("message", "注销成功");
		}
		return  result;
	}
	
	@ResponseBody
	@PostMapping("UserRecord")
	public Map<String,Object> getUserRecord(HttpSession session) {
		int userId = Integer.parseInt((String)session.getAttribute(Const.SESSION_USERID));
		Map<String,Object> result = new HashMap<>();
		SimpleDateFormat dataf = new SimpleDateFormat("yyyy-MM-dd");
		String endDate = dataf.format(new Date());
		String startDate = dataf.format(new Date(System.currentTimeMillis()-1000*60*60*24*7));
		List<UseLog> logs = this.userLogMapper.getUserUseLogByDate(userId, startDate, endDate);
		if(logs.size()<=0) {
			result.put("success","1");
			result.put("message", "无记录");
			return result;
		}else {
			result.put("success","0");
			return result;
		}
	}
	

	
	
	
	
	
//	@ResponseBody
//	@PostMapping("/userApplyCheck")
//	public Map<String,Object> userApplyCheck(HttpSession session,Model model) {
//		int sd = Integer.parseInt((String)session.getAttribute("User_ID"));
//		boolean hasnull = chestInfoService.applyChestCheck(sd);
//		Map<String,Object> map = new HashMap<String, Object>();
//		map.put("message", hasnull?1:0);
//		return map;
//	}
//	@ResponseBody
//	@PostMapping("UserOut")
//	public Map<String,Object> userOut(int Chest_Random) {
//		Map<String,Object> map = new HashMap<>();
//		if(chestInfoService.userRegistOut(Chest_Random)) {
//			map.put("success", "0");
//			map.put("message", "注销成功");
//		}else {
//			map.put("success", "1");
//			map.put("message", "注销失败");
//		}
//		return map;
//	}
	
	
	

	

	
//	@ResponseBody
//	@PostMapping("UserRecordCheck")
//	public Map<String,Object> userRecordCheck(HttpSession session) {
//		int userId = Integer.parseInt((String)session.getAttribute("User_ID"));
//		SimpleDateFormat dataf = new SimpleDateFormat("yyyy-MM-dd");
//		String endDate = dataf.format(new Date());
//		String startDate = dataf.format(new Date(System.currentTimeMillis()-1000*60*60*24*7));
//		List<UseLog> logs = this.userLogMapper.getUserUseLogByDate(userId, startDate, endDate);
//		Map<String, Object> map = new HashMap<>();
//		map.put("message", logs.size());
//		return map;
//	}
	

	

	
	
}
