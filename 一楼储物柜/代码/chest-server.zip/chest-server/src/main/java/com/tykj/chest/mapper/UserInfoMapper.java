package com.tykj.chest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tykj.chest.entity.UserInfo;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
public interface UserInfoMapper extends BaseMapper<UserInfo> {

}
