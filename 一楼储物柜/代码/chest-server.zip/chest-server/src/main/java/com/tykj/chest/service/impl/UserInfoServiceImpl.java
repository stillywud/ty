package com.tykj.chest.service.impl;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.tykj.chest.entity.UserInfo;
import com.tykj.chest.mapper.UserInfoMapper;
import com.tykj.chest.service.IUserInfoService;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@Service
public class UserInfoServiceImpl extends ServiceImpl<UserInfoMapper, UserInfo> implements IUserInfoService {

}
