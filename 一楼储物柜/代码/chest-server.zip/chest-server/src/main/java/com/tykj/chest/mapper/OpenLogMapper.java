package com.tykj.chest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tykj.chest.entity.OpenLog;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
public interface OpenLogMapper extends BaseMapper<OpenLog> {

}
