package com.tykj.chest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.tykj.chest.config.CommonConfig;
import com.tykj.chest.config.Const;
import com.tykj.chest.entity.ChestInfo;
import com.tykj.chest.mapper.ChestInfoMapper;
import com.tykj.chest.service.IChestInfoService;
import com.tykj.chest.utils.HttpClientUtil;

@Controller
public class LoginController {

	@Autowired
	CommonConfig commonConfig;
	
	@Autowired
	IChestInfoService chestInfoService;
	
	@Autowired
	ChestInfoMapper chestInfoMapper;
	
	
	/**
	 * 登陆  post
	 * @param session
	 * @param imei
	 * @return
	 */
	@GetMapping("/login")
	public ModelAndView login(HttpSession session,HttpServletRequest request,HttpServletResponse response,@RequestParam(value = "token", required = true) String token) {
//		imei = imei.replace("-", "");
//		
//		List<NameValuePair> paramList = new ArrayList <NameValuePair>();
//		paramList.add(new BasicNameValuePair("sysId",commonConfig.getOauthSysId()));
//        paramList.add(new BasicNameValuePair("client_id",commonConfig.getOauthClientId()));
//        paramList.add(new BasicNameValuePair("client_secret",commonConfig.getOauthClientSecret()));
//        paramList.add(new BasicNameValuePair("scope",commonConfig.getOauthScope()));
//        paramList.add(new BasicNameValuePair("grant_type",commonConfig.getOauthGrantType()));
//        paramList.add(new BasicNameValuePair("imei",imei));
//		
//		HttpEntity httpEntity = null;
//		try {
// 			httpEntity = new UrlEncodedFormEntity(paramList, "utf-8");
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		}
//	
//		String respContent = HttpClientUtil.getHttpPost(commonConfig.getOathUrl(), null, httpEntity);
//		JSONObject respJson = JSONObject.parseObject(respContent);
//		String token = respJson.getString("access_token");
		
		//改成田园传token
//		String token = request.getHeader("Authorization");
		Map<String, String> headers = new HashMap<>();
		System.out.println("登陆 token "+token);
		headers.put("Authorization", "Bearer "+token);
		String userInfo = HttpClientUtil.getHttpGet(commonConfig.getOauthUserUrl(), headers);
		if(userInfo == null) {//session 错误
			ModelAndView mv = new ModelAndView("tokenerror");
			return mv;
		  
		}
		JSONObject userJson = JSONObject.parseObject(userInfo);
		String DictOT_Name = userJson.containsKey("DictOT_Name")?userJson.getString("DictOT_Name"):"";
		session.setAttribute("Oprt_Name", userJson.getString("Oprt_Name").trim());
		session.setAttribute("User_ID", userJson.getString("Acnt_ID"));
		session.setAttribute("User_Type",DictOT_Name.trim());//人员类别
		session.setAttribute("token", token);
		//获取系统权限
		Map<String,String> params = new HashMap<>();
		params.put("SysI_ID", commonConfig.getOauthSysId());
		String userFunctions = HttpClientUtil.getHttpGet(commonConfig.getPermissionUrl(), headers,params);
		JSONObject functionObject = JSONObject.parseObject(userFunctions);
		JSONArray functionArray = functionObject.getJSONArray("FuncInfo");
		int applyCnt = 1;//最多申请柜子数量
		if(functionArray!=null && functionArray.size()>0) {
			for(int i=0;i<functionArray.size();i++) {
				JSONObject funObj = functionArray.getJSONObject(i);
				String functionName = funObj.getString("Func_Name");
				if(functionName!=null && functionName.trim().equals("申请长期柜子")) {
					session.setAttribute(Const.SESSION_LONGFUN_KEY,true);
				}else if(functionName!=null && functionName.matches(Const.APPLY2_FUNCITON_Name)) {
					applyCnt = Integer.valueOf(functionName.substring(2, 3));
				}
				 
			}
		}
		session.setAttribute(Const.SESSION_APPLYCOUNT, applyCnt);//最多可申请柜子的数量
		if(DictOT_Name.trim().equals(Const.ROLE_ADMIN_NAME)) {
			
			return new ModelAndView("SelectView");//重定向到管理员页面
		}else {
			int userId = Integer.parseInt((String)session.getAttribute(Const.SESSION_USERID));//用户id
			ModelAndView view = new ModelAndView("UserShowChest");
			List<ChestInfo> nullChestInfos = this.chestInfoMapper.getChestListByStatu(0);//空闲的柜子
			List<ChestInfo> useChestInfos = this.chestInfoService.getUseChestInfoList(userId);//占用中的柜子
			List<ChestInfo> myChestInfos = this.chestInfoMapper.getChestListByUserId(userId);//我的柜子
			view.addObject("nullChestInfos",nullChestInfos);
			view.addObject("useChestInfos",useChestInfos);
			view.addObject("myChestInfos",myChestInfos);
			return view;//跳转到用户页面
		}
	}
	
	@GetMapping("tokenerror")
	public String tokenerror() {
		return "tokenerror";
	}
	
	
}
