package com.tykj.chest.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@TableName("UserInfo")
public class UserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "User_ID", type = IdType.AUTO)
    private Integer userId;

    @TableField("User_Name")
    private String userName;

    @TableField("User_Pass")
    private String userPass;

    @TableField("User_Type")
    private Boolean userType;

    @TableField("Staff_ID")
    private Integer staffId;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }
    public Boolean getUserType() {
        return userType;
    }

    public void setUserType(Boolean userType) {
        this.userType = userType;
    }
    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
        "userId=" + userId +
        ", userName=" + userName +
        ", userPass=" + userPass +
        ", userType=" + userType +
        ", staffId=" + staffId +
        "}";
    }
}
