package com.tykj.chest.service.impl;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.tykj.chest.entity.StaffInfo;
import com.tykj.chest.mapper.StaffInfoMapper;
import com.tykj.chest.service.IStaffInfoService;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@Service
public class StaffInfoServiceImpl extends ServiceImpl<StaffInfoMapper, StaffInfo> implements IStaffInfoService {

}
