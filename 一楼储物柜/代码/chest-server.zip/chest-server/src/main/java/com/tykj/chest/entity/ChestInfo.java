package com.tykj.chest.entity;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@TableName("ChestInfo")
public class ChestInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "Chest_ID", type = IdType.AUTO)
    private Integer chestId;

    @TableField("Chest_Site")
    private String chestSite;

    @TableField("Chest_Type")
    private Boolean chestType;

    @TableField("Chest_State")
    private Boolean chestState;

    @TableField("Chest_Remark")
    private String chestRemark;

    @TableField("Chest_GetDate")
	private Date chestGetdate;

    @TableField("Chest_OutDate")
    private Date chestOutdate;

    @TableField("User_ID")
    private Integer userId;
    
    @TableField("user_name")
    private String userName;

    @TableField("Chest_Random")
    private Integer chestRandom;

    @TableField("Chest_Longtime")
    private Integer chestLongtime;
    
    @TableField(exist=false)
    private String staffName;
    
    @TableField("lockstatu")
    private Boolean lockstatu;

    public Integer getChestId() {
        return chestId;
    }

    public void setChestId(Integer chestId) {
        this.chestId = chestId;
    }
    public String getChestSite() {
        return chestSite;
    }

    public void setChestSite(String chestSite) {
        this.chestSite = chestSite;
    }
    public Boolean getChestType() {
        return chestType;
    }

    public void setChestType(Boolean chestType) {
        this.chestType = chestType;
    }
    public Boolean getChestState() {
        return chestState;
    }

    public void setChestState(Boolean chestState) {
        this.chestState = chestState;
    }
    public String getChestRemark() {
        return chestRemark;
    }

    public void setChestRemark(String chestRemark) {
        this.chestRemark = chestRemark;
    }

    
    public Date getChestGetdate() {
		return chestGetdate;
	}

	public void setChestGetdate(Date chestGetdate) {
		this.chestGetdate = chestGetdate;
	}

	public Date getChestOutdate() {
		return chestOutdate;
	}

	public void setChestOutdate(Date chestOutdate) {
		this.chestOutdate = chestOutdate;
	}

	public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getChestRandom() {
        return chestRandom;
    }

    public void setChestRandom(Integer chestRandom) {
        this.chestRandom = chestRandom;
    }
    public Integer getChestLongtime() {
        return chestLongtime;
    }

    public void setChestLongtime(Integer chestLongtime) {
        this.chestLongtime = chestLongtime;
    }
    
    

    public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	
	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	

	public Boolean getLockstatu() {
		return lockstatu;
	}

	public void setLockstatu(Boolean lockstatu) {
		this.lockstatu = lockstatu;
	}

	@Override
    public String toString() {
        return "ChestInfo{" +
        "chestId=" + chestId +
        ", chestSite=" + chestSite +
        ", chestType=" + chestType +
        ", chestState=" + chestState +
        ", chestRemark=" + chestRemark +
        ", chestGetdate=" + chestGetdate +
        ", chestOutdate=" + chestOutdate +
        ", userId=" + userId +
        ", chestRandom=" + chestRandom +
        ", chestLongtime=" + chestLongtime +
        "}";
    }
}
