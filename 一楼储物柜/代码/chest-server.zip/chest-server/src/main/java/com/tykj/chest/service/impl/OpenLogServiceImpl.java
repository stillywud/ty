package com.tykj.chest.service.impl;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.tykj.chest.entity.OpenLog;
import com.tykj.chest.mapper.OpenLogMapper;
import com.tykj.chest.service.IOpenLogService;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@Service
public class OpenLogServiceImpl extends ServiceImpl<OpenLogMapper, OpenLog> implements IOpenLogService {

	@Override
	public void addOpenLog(int chestId,int userId,String userName,String userType) {
		OpenLog openLog = new OpenLog();
		openLog.setChestId(chestId);
		openLog.setUserId(userId);
		openLog.setOpenlUsername(userName);
		openLog.setOpenlUsertype(userType);
		openLog.setOpenlOpendate(new Date());
		save(openLog);
		
	}
}
