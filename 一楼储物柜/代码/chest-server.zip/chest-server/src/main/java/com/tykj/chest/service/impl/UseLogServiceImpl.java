package com.tykj.chest.service.impl;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.tykj.chest.entity.UseLog;
import com.tykj.chest.mapper.UseLogMapper;
import com.tykj.chest.service.IUseLogService;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@Service
public class UseLogServiceImpl extends ServiceImpl<UseLogMapper, UseLog> implements IUseLogService {

	
	public void useLogApply(int userId, int chestId, int chestRandom, String userName, String userType) {
		UseLog useLog = new UseLog();
		useLog.setUserId(userId);
		useLog.setChestId(chestId);
		useLog.setChestRandom(chestRandom);
		useLog.setUselUsername(userName);
		useLog.setUselUsertype(userType);
		useLog.setUselGetdate(new Date());
		save(useLog);
	}

	@Override
	public void logOutApply(Integer chestId) {
		UseLog useLog = new UseLog();
		useLog.setUselOutdate(new Date());
		UpdateWrapper<UseLog> uw = new UpdateWrapper<>();
		uw.eq("Chest_ID", chestId);
		update(useLog, uw);
		
	}
}
