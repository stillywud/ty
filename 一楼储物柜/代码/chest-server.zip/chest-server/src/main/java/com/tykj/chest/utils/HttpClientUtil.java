package com.tykj.chest.utils;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpUtils;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;


public class HttpClientUtil {
	private static Logger logger = Logger.getLogger(HttpClientUtil.class);
	
	public static String getHttpGet(String url,Map<String,String> headers) {
		return getHttpGet(url,null,null,null,null,headers);
	}
	public static String getHttpGet(String url,Map<String,String> headers,Map<String, String> params) {
		return getHttpGet(url,null,null,null,params,headers);
	}

	public static String getHttpGet(String url,String scheme, String host, String path, Map<String, String> param,Map<String,String> headers) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			URIBuilder uriBuilder = null;
			if(url==null || "".equals(url.trim())) {
				uriBuilder = new URIBuilder().setScheme(scheme).setHost(host).setPath(path);
			}else {
				uriBuilder = new URIBuilder(url);
			}
			if (param != null) {
				Iterator<String> iterator = param.keySet().iterator();
				while (iterator.hasNext()) {
					String key = iterator.next();
					uriBuilder.addParameter(key, param.get(key));
				}
			}
			
			URI uri = uriBuilder.build();
			HttpGet httpGet = new HttpGet(uri);
			logger.debug(httpGet.getURI().toString());
			if(headers != null) {
				for(String headKey : headers.keySet()) {
					httpGet.setHeader(headKey,headers.get(headKey) );
				}
			}
			response = httpClient.execute(httpGet);
			if (response.getStatusLine().getStatusCode() == 200) {
				return EntityUtils.toString(response.getEntity(), "utf-8");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (httpClient != null) {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
		return null;
	}
	
	public static String getHttpPost(String url,Map<String,String> headers,HttpEntity requestBody) {
		return getHttpPost(url,null, null, null, null, headers,requestBody);
	}
	
	public static String getHttpPost(String scheme, String host, String path, HttpEntity requestBody) {
		return getHttpPost(scheme, host, path, null, requestBody);
	}

	public static String getHttpPost(String scheme, String host, String path, Map<String, String> param, HttpEntity requestBody) {
		return getHttpPost(null,scheme, host, path, param,null, requestBody);
	}
	
	
	
	public static String getHttpPost(String url,String scheme, String host, String path, Map<String, String> param, Map<String,String> headers,HttpEntity requestBody) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			URIBuilder uriBuilder = null;
			if(url==null || "".equals(url.trim())) {
				uriBuilder = new URIBuilder().setScheme(scheme).setHost(host).setPath(path);
			}else {
				uriBuilder = new URIBuilder(url);
			}
			if (param != null) {
				Iterator<String> iterator = param.keySet().iterator();
				while (iterator.hasNext()) {
					String key = iterator.next();
					uriBuilder.addParameter(key, param.get(key));
				}
			}
			
			URI uri = uriBuilder.build();
			HttpPost httpPost = new HttpPost(uri);
			if(headers != null) {
				for(String headKey : headers.keySet()) {
					httpPost.setHeader(headKey,headers.get(headKey) );
				}
			}
			
			httpPost.setEntity(requestBody);
			response = httpClient.execute(httpPost);
			if (response.getStatusLine().getStatusCode() == 200) {
				return EntityUtils.toString(response.getEntity(), "utf-8");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (httpClient != null) {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
		return null;
	}
	
	public static String getHttpPostJson(String scheme, String host, String path, Map<String, String> param, String requestBody) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			
			URIBuilder uriBuilder = new URIBuilder().setScheme(scheme).setHost(host).setPath(path);
			MultipartEntityBuilder multipartEntityBuilder=  MultipartEntityBuilder.create();
			ContentType contentType = ContentType.create("text/plain", Charset.forName("UTF-8"));
			if (param != null) {
				Iterator<String> iterator = param.keySet().iterator();
				while (iterator.hasNext()) {
					String key = iterator.next();
//					multipartEntityBuilder.addTextBody(key, param.get(key));
					multipartEntityBuilder.addTextBody(key, param.get(key), contentType);
//					pairList.add(new BasicNameValuePair(key, param.get(key)));
				}
			}
			URI uri = uriBuilder.build();
			HttpPost httpPost = new HttpPost(uri);
			httpPost.setEntity(multipartEntityBuilder.build());
			response = httpClient.execute(httpPost);
			if (response.getStatusLine().getStatusCode() == 200) {
				return EntityUtils.toString(response.getEntity(), "utf-8");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
			if (httpClient != null) {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e.getMessage());
				}
			}
		}
		return null;
	}

}
