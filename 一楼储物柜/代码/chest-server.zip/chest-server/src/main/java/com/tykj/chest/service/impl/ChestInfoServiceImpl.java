package com.tykj.chest.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.tykj.chest.entity.ChestInfo;
import com.tykj.chest.mapper.ChestInfoMapper;
import com.tykj.chest.service.IChestInfoService;
import com.tykj.chest.service.IUseLogService;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@Service
public class ChestInfoServiceImpl extends ServiceImpl<ChestInfoMapper, ChestInfo> implements IChestInfoService {
	

	@Autowired
	ChestInfoMapper chestInfoMapper;
	
	@Autowired
	IUseLogService useLogService;
	
	@Transactional
	@Override
	public Map<String,Object> applyChest(int chestId,int canApplyCnt ,int userId,String usreName, String userType, boolean isLong) {
		
		
		Map<String,Object> result = new HashMap<>();
		
		ChestInfo chestInfo = this.getChestInfoById(chestId);
		if(chestInfo.getChestState()||chestInfo.getLockstatu()) {
			result.put("success", "1");
			result.put("message", "该柜子已被占用");
			return result;
		}
		QueryWrapper<ChestInfo> qwp = new QueryWrapper<>();
		qwp.eq("User_ID", userId);
		int count = count(qwp);
		if(canApplyCnt - count <= 0) {
			result.put("success", "1");
			result.put("message", "柜子数量达到上限");
			return result;
		}
		Random random = new Random();
		int randomCode = 10000000+random.nextInt(89999999);//随机码
		chestInfo.setChestRandom(randomCode);
		chestInfo.setChestState(true);
		chestInfo.setUserId(userId);
		chestInfo.setUserName(usreName);
		chestInfo.setChestGetdate(new Date());
		chestInfo.setChestType(isLong);
		
		if(updateById(chestInfo)) {//修改柜子状态
			useLogService.useLogApply(userId,chestInfo.getChestId(),randomCode,usreName,userType);
			result.put("success", "0");
			result.put("message", "申请成功");
		}else {
			result.put("success", "1");
			result.put("message", "申请失败");
		}
		return result;
	}
	
//	@Override
//	public boolean applyChestCheck(int userId) {
//		ChestInfo chestInfo = getChestInfo(userId);
//		if(chestInfo == null) {
//			List<ChestInfo> nullChecks = chestInfoMapper.getNullChest();//获取空箱列表
//			if(nullChecks==null || nullChecks.size()<=0) {
//				return false;
//			}
//		}
//		return true;
//	}

	@Override
	public List<ChestInfo> getChestInfo(int userId) {
		QueryWrapper<ChestInfo> qwp = new QueryWrapper<>();
		qwp.eq("User_ID", userId);
		List<ChestInfo> chestInfoList = list(qwp);
		return chestInfoList;
	}
	@Override
	public ChestInfo getChestInfoById(int chestId) {
		return chestInfoMapper.selectById(chestId);
	}

	@Transactional
	@Override
	public boolean userRegistOut(int chestId) {
		if(chestInfoMapper.userRegistOut(chestId)) {//修改柜子状态
			useLogService.logOutApply(chestId);
			return true;
		}
		return false;
	}
	
	@Override
	public ChestInfo getChestInfoByRandom(int chestRandom) {
		QueryWrapper<ChestInfo> qwp = new QueryWrapper<>();
		qwp.eq("Chest_Random", chestRandom);
		return getOne(qwp);
		
		
	}

	@Override
	@Transactional
	public boolean changeChestType(int chestId, boolean chestType, int userId,String chestRandom,String userName,String userType) {
		
		ChestInfo chestInfo = new ChestInfo();
		chestInfo.setChestId(chestId);
		if(chestType) {//短期改长期
//			Random random = new Random();
//			int chestRandom1 = random.nextInt(88888888)+10000000;
//			chestInfo.setChestRandom(chestRandom1);
			chestInfo.setChestId(chestId);
//			chestInfo.setChestGetdate(new Date());
			chestInfo.setChestType(chestType);
//			chestInfo.setChestState(chestType);
			if(updateById(chestInfo)){
//				useLogService.useLogApply(userId, chestId, chestInfo.getChestRandom(), userName, userType);
				return true;
			}else {
				return false;
			}
		}else{//长期改短期
			if(chestInfoMapper.changeChestTypeToShort(chestId)) {
				useLogService.logOutApply(Integer.parseInt(chestRandom));
				return true;
			}else {
				return false;
			}
			
		}
		
		
		
	}

	@Override
	public boolean setRemark(int chestId, String chestRemark) {
		ChestInfo chestInfo = new ChestInfo();
		chestInfo.setChestId(chestId);
		chestInfo.setChestRemark(chestRemark);
		return updateById(chestInfo);
	}
	
	/**
	 * 锁定未注销的短期柜子
	 */
	@Override
	public void lockShortBoxes() {
		this.chestInfoMapper.lockShortBoxes();
	}
	
	/**
	 * 用户获取已经占用的柜子
	 * @param userId
	 * @return
	 */
	@Override
	public List<ChestInfo> getUseChestInfoList(Integer userId){
		QueryWrapper<ChestInfo> qw = new QueryWrapper<>();
		qw.eq("Chest_State", 1);
		qw.ne("User_ID", userId);
		List<ChestInfo> chestInfos = list(qw);
		return chestInfos;
	}

}
