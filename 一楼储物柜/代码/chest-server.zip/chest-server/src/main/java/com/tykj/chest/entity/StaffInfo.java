package com.tykj.chest.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@TableName("StaffInfo")
public class StaffInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "Staff_ID", type = IdType.AUTO)
    private Integer staffId;

    @TableField("Staff_Name")
    private String staffName;

    @TableField("Staff_Phone")
    private String staffPhone;

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }
    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }
    public String getStaffPhone() {
        return staffPhone;
    }

    public void setStaffPhone(String staffPhone) {
        this.staffPhone = staffPhone;
    }

    @Override
    public String toString() {
        return "StaffInfo{" +
        "staffId=" + staffId +
        ", staffName=" + staffName +
        ", staffPhone=" + staffPhone +
        "}";
    }
}
