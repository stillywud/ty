package com.tykj.chest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.tykj.chest.entity.OpenLog;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
public interface IOpenLogService extends IService<OpenLog> {

	
	public void addOpenLog(int chestId,int userId,String userName,String userType);
}
