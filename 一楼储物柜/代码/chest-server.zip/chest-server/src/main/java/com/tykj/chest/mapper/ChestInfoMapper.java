package com.tykj.chest.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tykj.chest.entity.ChestInfo;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@Mapper
public interface ChestInfoMapper extends BaseMapper<ChestInfo> {

	
	public List<ChestInfo> selectChestInfoList();
	
	/**
	 * 查询空柜子
	 * @return
	 */
	public List<ChestInfo> getNullChest();
	
	/**
	 * 根据柜子状态查询柜子
	 * @return
	 */
	List<ChestInfo> getChestListByStatu(@Param("statu") Integer statu);
	
	/**
	 * 根据用户id查询柜子列表
	 * @return
	 */
	List<ChestInfo> getChestListByUserId(@Param("userId") Integer userId);
	
	
	
	/**
	 * 用户注销
	 * @param chestRandom
	 * @return
	 */
	public boolean userRegistOut(@Param("chestId")Integer chestId);
	
	
	public boolean changeChestTypeToShort(@Param("chestId")Integer chestId);
	
	/**
	 * 锁定未注销的短期柜子
	 */
	public void lockShortBoxes();
}
