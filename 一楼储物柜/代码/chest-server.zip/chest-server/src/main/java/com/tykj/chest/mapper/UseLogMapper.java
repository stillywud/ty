package com.tykj.chest.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tykj.chest.entity.UseLog;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
public interface UseLogMapper extends BaseMapper<UseLog> {

	/**
	 * 管理员获取使用记录
	 * @param chestId
	 * @return
	 */
	public List<UseLog> getAdminUseLog(@Param("chestId") Integer chestId);
	
	/**
	 * 管理员获取使用记录
	 * @param chestId
	 * @return
	 */
	public List<UseLog> getAdminUseLogByDate(@Param("Chest_ID") Integer chestId,@Param("UseL_GetDate1") String startDate,@Param("UseL_GetDate2") String endDate);
	
	/**
	 * 普通用户查看使用记录(问题：如果刚注册这个柜子还没注销，查使用记录查不到打开的记录)
	 * @param userId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public List<UseLog> getUserUseLogByDate(@Param("User_ID") Integer userId,@Param("startDate") String startDate,@Param("endDate") String endDate);
	
}
