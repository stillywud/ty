package com.tykj.chest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.tykj.chest.entity.UserInfo;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
public interface IUserInfoService extends IService<UserInfo> {

}
