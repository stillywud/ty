package com.tykj.chest.config;

public class Const {

	//本机
	//public static final String SERVER_ADDRESS="http://192.168.19.61:8080/chest";
	//测试101
	//public static final String SERVER_ADDRESS="http://soft.tygps.com:10445/chest";
	//正式
	public static final String SERVER_ADDRESS="https://www.tymics.com.cn/hbxs/ccbh/chest";
	
	//public static final String ROLE_ADMIN_NAME="服务人员";
	public static final String ROLE_ADMIN_NAME="柜子管理员";
	
	
	public static final String LONG_FUNCITON_Name = "申请长期柜子";
	public static final String APPLY2_FUNCITON_Name = "申请\\d个柜子";
	/**
	 * 是否可申请长期柜子
	 */
	public static final String SESSION_LONGFUN_KEY = "LONGFUN";
	public static final String SESSION_APPLYCOUNT = "APPLYCOUNT";
	public static final String SESSION_USERID = "User_ID";
	
}
