package com.tykj.chest.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.tykj.chest.service.IChestInfoService;

@Component
@EnableScheduling
public class ScheduleTask {
	
	@Autowired
	IChestInfoService chestInfoService;

	/**
	 * 22点 锁定所有短期箱子
	 */
	@Scheduled(cron="0 0 15 ? * *")
	public void clear() {
		chestInfoService.lockShortBoxes();
	}
	

}
