package com.tykj.chest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tykj.chest.entity.StaffInfo;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
public interface StaffInfoMapper extends BaseMapper<StaffInfo> {

}
