package com.tykj.chest.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CommonConfig {


	@Value("${common.oauth.sys_id}")
	private String oauthSysId;
	@Value("${common.oauth.client_id}")
	private String oauthClientId;
	@Value("${common.oauth.client_secret}")
	private String oauthClientSecret;
	@Value("${common.oauth.scope}")
	private String oauthScope;
	@Value("${common.oauth.grant_type}")
	private String oauthGrantType;
	@Value("${common.oauth.user.url}")
	private String oauthUserUrl;
	
	@Value("${common.oauth.permission.url}")
	private String permissionUrl;
	
	@Value("${common.locker.resurlN}")
	private String resUrlN;
	@Value("${common.locker.resurlS}")
	private String resUrlS;
	
	
	public String getOauthSysId() {
		return oauthSysId;
	}
	public void setOauthSysId(String oauthSysId) {
		this.oauthSysId = oauthSysId;
	}
	public String getOauthClientId() {
		return oauthClientId;
	}
	public void setOauthClientId(String oauthClientId) {
		this.oauthClientId = oauthClientId;
	}
	public String getOauthClientSecret() {
		return oauthClientSecret;
	}
	public void setOauthClientSecret(String oauthClientSecret) {
		this.oauthClientSecret = oauthClientSecret;
	}
	public String getOauthScope() {
		return oauthScope;
	}
	public void setOauthScope(String oauthScope) {
		this.oauthScope = oauthScope;
	}
	public String getOauthGrantType() {
		return oauthGrantType;
	}
	public void setOauthGrantType(String oauthGrantType) {
		this.oauthGrantType = oauthGrantType;
	}
	public String getOauthUserUrl() {
		return oauthUserUrl;
	}
	public void setOauthUserUrl(String oauthUserUrl) {
		this.oauthUserUrl = oauthUserUrl;
	}
	public String getResUrlN() {
		return resUrlN;
	}
	public void setResUrlN(String resUrlN) {
		this.resUrlN = resUrlN;
	}
	public String getResUrlS() {
		return resUrlS;
	}
	public void setResUrlS(String resUrlS) {
		this.resUrlS = resUrlS;
	}
	public String getPermissionUrl() {
		return permissionUrl;
	}
	public void setPermissionUrl(String permissionUrl) {
		this.permissionUrl = permissionUrl;
	}
	

	
	
	

	
	
	
	

}
