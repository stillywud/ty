package com.tykj.chest.controller;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.http.HttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.tykj.chest.config.CommonConfig;
import com.tykj.chest.entity.ChestInfo;
import com.tykj.chest.entity.UseLog;
import com.tykj.chest.mapper.ChestInfoMapper;
import com.tykj.chest.mapper.UseLogMapper;
import com.tykj.chest.service.IChestInfoService;
import com.tykj.chest.service.IOpenLogService;
import com.tykj.chest.service.IUseLogService;
import com.tykj.chest.utils.HttpClientUtil;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	ChestInfoMapper chestInfoMapper;
	@Autowired
	UseLogMapper useLogMapper;
	
	@Autowired
	CommonConfig commonConfig;
	
	@Autowired
	IOpenLogService openLogService;
	
	
	@Autowired
	IUseLogService useLogService;
	
	@Autowired
	IChestInfoService chestInfoService;

	@GetMapping("/selectLoginUser")
	public String selectLoginUser(Model model,HttpSession session,String pra) {
		int userId = Integer.parseInt((String)session.getAttribute("User_ID"));
		if("1".equals(pra)) {
//			List<ChestInfo> chestInfos = chestInfoMapper.selectChestInfoList();
			List<ChestInfo> nullChestInfos = this.chestInfoMapper.getChestListByStatu(0);//空闲的柜子
			List<ChestInfo> useChestInfos = this.chestInfoMapper.getChestListByStatu(1);//占用的柜子
			model.addAttribute("nullChestInfos",nullChestInfos);
			model.addAttribute("useChestInfos",useChestInfos);
			return "ShowChest";
		}else {
			List<ChestInfo> nullChestInfos = this.chestInfoMapper.getChestListByStatu(0);//空闲的柜子
			List<ChestInfo> useChestInfos = this.chestInfoService.getUseChestInfoList(userId);//占用中的柜子
			List<ChestInfo> myChestInfos = this.chestInfoMapper.getChestListByUserId(userId);//我的柜子
			model.addAttribute("nullChestInfos",nullChestInfos);
			model.addAttribute("useChestInfos",useChestInfos);
			model.addAttribute("myChestInfos",myChestInfos);
			return "UserShowChest";
			
		}
	}
	@GetMapping("/SelectView")
	public String selectView() {
		return "SelectView";
	}
	
	@GetMapping("/AdminMain")
	public String adminMain(Model model,@RequestParam("Chest_ID") Integer chestId) {
		ChestInfo chestInfo = chestInfoMapper.selectById(chestId);
		model.addAttribute("Chest_ID",chestInfo.getChestId());
		model.addAttribute("Chest_Site",chestInfo.getChestSite());
		model.addAttribute("userName",chestInfo.getUserName());
		if(chestInfo.getChestType()) {
			model.addAttribute("Chest_Type","长期柜子");
			model.addAttribute("Chest_Type2","短期柜子");
		}else {
			model.addAttribute("Chest_Type2","长期柜子");
			model.addAttribute("Chest_Type","短期柜子");
		}
		
		model.addAttribute("Chest_Remark",chestInfo.getChestRemark()==null?"":chestInfo.getChestRemark());
		
		if(chestInfo.getChestRandom()==null||chestInfo.getChestRandom()==0) {
			model.addAttribute("Chest_Random",chestInfo.getChestId());
		}else {
			model.addAttribute("Chest_Random",chestInfo.getChestRandom());
		}
		
		model.addAttribute("Chest_State",chestInfo.getChestState());
		return "AdminMain";
	}
	
	@ResponseBody
	@PostMapping("/Open")
	public Map<String, Object> open(HttpSession session,Model model ,@RequestParam("Chest_ID") Integer chestId) {
		Map<String,Object> map = new HashMap<>();
		int userId = Integer.parseInt((String)session.getAttribute("User_ID"));
		String userName = (String)session.getAttribute("Oprt_Name");
		String userType = (String)session.getAttribute("User_Type");
		String url = "";
		if(chestId >=1 && chestId <= 72) {
			url = commonConfig.getResUrlS();
		}else {
			url = commonConfig.getResUrlN();
		}
		
		String p = "{'accountname':'tykj20180101','accountpwd':'tykj20180101','boxnumber':'" + chestId + "'}";
		byte[] bytes = null;
		try {
			bytes = p.getBytes("utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
//		HttpEntity requestBody = new StringEntity(p,ContentType.APPLICATION_JSON);
		HttpEntity requestBody = new ByteArrayEntity(bytes);
		String responseStr = HttpClientUtil.getHttpPost(url, null, requestBody);
		if(responseStr == null) {
			map.put("message", "打开失败");
			return map;
		}
		JSONObject jsb = JSONObject.parseObject(responseStr);
		String statuscode = jsb.getString("statuscode");
		String respdescs = jsb.getString("respdescs");
		if(statuscode!=null && statuscode.equals("1")) {
			openLogService.addOpenLog(chestId, userId, userName, userType);
			map.put("message", "打开成功");
			//注销柜子
//			ChestInfo chestInfo = chestInfoService.getChestInfoById(chestId);
//			if(chestInfo != null && chestInfo.getChestState()) {
//				chestInfoService.userRegistOut(chestId);
//			}
			return map;
		}else {
			map.put("message", "打开失败");
			return map;
		}
	}
	
	@ResponseBody
	@PostMapping("/RecordSize")
	public Map<String,Object> hasAdminRecords(@RequestParam("Chest_ID") Integer chestId,@RequestParam("Chest_Site") String chestSite){
		List<UseLog> useLogs = useLogMapper.getAdminUseLog(chestId);
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("recsize", useLogs.size());
		return map;
	}
	
	@GetMapping("/Record")
	public String adminRecords(Model model,@RequestParam("Chest_ID") Integer chestId,@RequestParam("Chest_Site") String chestSite) {
		List<UseLog> useLogs = useLogMapper.getAdminUseLog(chestId);
		model.addAttribute("Chest_ID",chestId);
		model.addAttribute("Chest_Site",chestSite);
		model.addAttribute("Record",useLogs);
		return "adminRecord";
		
	}
	
	@GetMapping("/Record1")
	public String adminRecords1(Model model,@RequestParam("Chest_ID") Integer chestId,@RequestParam("UseL_GetDate1") String startTime,
			@RequestParam("UseL_GetDate2")String endTime,@RequestParam("Chest_Site") String chestSite) {
		List<UseLog> useLogs = new ArrayList<UseLog>();
		if("".equals(startTime) && "".equals(endTime)) {
			useLogs = useLogMapper.getAdminUseLog(chestId);
		}else {
			if(!"".equals(startTime) && "".equals(endTime)) {
				DateFormat df = new SimpleDateFormat("YYYY-MM-dd");
				endTime = df.format(new Date());
			}
			useLogs = useLogMapper.getAdminUseLogByDate(chestId,startTime,endTime);
		}
		
		model.addAttribute("Chest_ID",chestId);
		model.addAttribute("Chest_Site",chestSite);
		model.addAttribute("Record",useLogs);
		return "adminRecord";
	}
	@ResponseBody
	@PostMapping("/Record1Size")
	public Map<String,Object> adminRecords1Size(Model model,@RequestParam("Chest_ID") Integer chestId,@RequestParam("UseL_GetDate1") String startTime,
			@RequestParam("UseL_GetDate2")String endTime,@RequestParam("Chest_Site") String chestSite) {
		List<UseLog> useLogs = useLogMapper.getAdminUseLogByDate(chestId,startTime,endTime);
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("recsize", useLogs.size());
		return map;
	}
	
	
	@ResponseBody
	@PostMapping("SetStyle")
	public Map<String,Object> setStyle(HttpSession session,@RequestParam("Chest_ID") Integer chestId,@RequestParam("Chest_Type") String chestType){
		String userName = (String)session.getAttribute("Oprt_Name");
		String userType = (String)session.getAttribute("User_Type");
		int userId = Integer.parseInt((String)session.getAttribute("User_ID"));
		Map<String,Object> message = new HashMap<>();
		ChestInfo chestInfo = this.chestInfoService.getChestInfoById(chestId);
		boolean chesttype = "长期柜子".equals(chestType);
		if(chesttype && "True".equals(chestInfo.getChestState())) {//长期柜子 如果是占有状态
			message.put("message", "该短期柜子为占用状态不能修改为长期柜子");
			return message;
		}
		if(chestInfoService.changeChestType(chestId, chesttype, userId,String.valueOf(chestInfo.getChestRandom()),userName,userType)) {
			message.put("message", "修改成功");
			return message;
		}else {
			message.put("message", "修改失败");
			return message;
		}
		
	}
	
	@ResponseBody
	@PostMapping("Remark")
	public Map<String,Object> setRemark(@RequestParam("Chest_ID") Integer chestId,@RequestParam("Chest_Remark") String chestRemark){
		Map<String,Object> map = new HashMap<>();
		if(chestInfoService.setRemark(chestId, chestRemark)) {
			map.put("message", "修改成功");
		}else {
			map.put("message", "修改失败");
		}
		return map;
	}
	
	/**
	 * 强制注销
	 * @return
	 */
	@PostMapping("forcelogout")
	public String forcelogout(Model model,@RequestParam("Chest_ID") Integer chestId) {
		chestInfoService.userRegistOut(chestId);
		List<ChestInfo> nullChestInfos = this.chestInfoMapper.getChestListByStatu(0);//空闲的柜子
		List<ChestInfo> useChestInfos = this.chestInfoMapper.getChestListByStatu(1);//占用的柜子
		model.addAttribute("nullChestInfos",nullChestInfos);
		model.addAttribute("useChestInfos",useChestInfos);
		return "ShowChest";
	}
	
}

