package com.tykj.chest.service;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.tykj.chest.entity.ChestInfo;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
public interface IChestInfoService extends IService<ChestInfo> {

	public Map<String,Object> applyChest(int chestId,int canApplyCnt ,int userId,String usreName, String userType, boolean isLong);
	
	
	
	/**
	 * 获取已经申请的柜子
	 * @return
	 */
	public List<ChestInfo> getChestInfo(int userId);
	
	/**
	 * 根据箱子id获取箱子
	 * @param chestId
	 * @return
	 */
	public ChestInfo getChestInfoById(int chestId);
	
	/**
	 * 用户注销
	 * @param chestRandom
	 * @return
	 */
	public boolean userRegistOut(int chestId);
	
	/**
	 * 根据随机码查询柜子信息
	 * @param chestRandom
	 * @return
	 */
	public ChestInfo getChestInfoByRandom(int chestRandom);
	
	
	public boolean changeChestType(int chestId,boolean chestType,int userId,String chestRandom,String userName,String userType);
	
	
	public boolean setRemark(int chestId,String chestRemark);
	
	/**
	 * 锁定未注销的短期柜子
	 */
	public void lockShortBoxes();
	
	public List<ChestInfo> getUseChestInfoList(Integer userId);
}
