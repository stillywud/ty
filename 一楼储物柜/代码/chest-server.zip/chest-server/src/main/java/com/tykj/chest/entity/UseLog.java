package com.tykj.chest.entity;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author lizengcun
 * @since 2019-10-10
 */
@TableName("UseLog")
public class UseLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "UseL_ID", type = IdType.AUTO)
    private Integer uselId;

    @TableField("Chest_ID")
    private Integer chestId;

    @TableField("User_ID")
    private Integer userId;

    @TableField("UseL_GetDate")
    private Date uselGetdate;

    @TableField("UseL_OutDate")
    private Date uselOutdate;

    @TableField("Chest_Random")
    private Integer chestRandom;

    @TableField("UseL_UserName")
    private String uselUsername;

    @TableField("UseL_UserType")
    private String uselUsertype;
    
    @TableField(exist=false)
    private String shenzhu;
    
    @TableField(exist=false)
    private String date;
    
    @TableField(exist=false)
    private String time;
    
    @TableField(exist=false)
    private String chestSite;

    public Integer getUselId() {
        return uselId;
    }

    public void setUselId(Integer uselId) {
        this.uselId = uselId;
    }
    public Integer getChestId() {
        return chestId;
    }

    public void setChestId(Integer chestId) {
        this.chestId = chestId;
    }
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Date getUselGetdate() {
        return uselGetdate;
    }

    public void setUselGetdate(Date uselGetdate) {
        this.uselGetdate = uselGetdate;
    }
    public Date getUselOutdate() {
        return uselOutdate;
    }

    public void setUselOutdate(Date uselOutdate) {
        this.uselOutdate = uselOutdate;
    }
    public Integer getChestRandom() {
        return chestRandom;
    }

    public void setChestRandom(Integer chestRandom) {
        this.chestRandom = chestRandom;
    }
    public String getUselUsername() {
        return uselUsername;
    }

    public void setUselUsername(String uselUsername) {
        this.uselUsername = uselUsername;
    }
    public String getUselUsertype() {
        return uselUsertype;
    }

    public void setUselUsertype(String uselUsertype) {
        this.uselUsertype = uselUsertype;
    }

    @Override
    public String toString() {
        return "UseLog{" +
        "uselId=" + uselId +
        ", chestId=" + chestId +
        ", userId=" + userId +
        ", uselGetdate=" + uselGetdate +
        ", uselOutdate=" + uselOutdate +
        ", chestRandom=" + chestRandom +
        ", uselUsername=" + uselUsername +
        ", uselUsertype=" + uselUsertype +
        "}";
    }

	public String getShenzhu() {
		return shenzhu;
	}

	public void setShenzhu(String shenzhu) {
		this.shenzhu = shenzhu;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getChestSite() {
		return chestSite;
	}

	public void setChestSite(String chestSite) {
		this.chestSite = chestSite;
	}
}
