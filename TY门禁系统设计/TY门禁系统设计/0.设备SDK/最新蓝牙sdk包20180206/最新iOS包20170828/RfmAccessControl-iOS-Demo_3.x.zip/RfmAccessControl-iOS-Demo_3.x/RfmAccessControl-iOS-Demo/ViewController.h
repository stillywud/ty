//
//  ViewController.h
//  RfmAccessControl-iOS-Demo
//
//  Created by yeyufeng on 2017/3/24.
//  Copyright © 2017年 REFORMER. All rights reserved.
//

#import <UIKit/UIKit.h>

//引入立方设备SDK头文件
#import <RfmAccessControl/RfmAccessControl.h>

//其他头文件
#import "NSData+YYExtend.h"
#import "NSString+YYExtend.h"

@interface ViewController : UIViewController <RfmSessionDelegate, UIActionSheetDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *messageLabel;

@end
