//
//  SettingViewController.m
//  RfmAccessControl-iOS-Demo
//
//  Created by yeyufeng on 2017/3/24.
//  Copyright © 2017年 REFORMER. All rights reserved.
//

#import "SettingViewController.h"

@interface SettingViewController ()

@property (weak, nonatomic) IBOutlet UITextField *devKeyField;
@property (weak, nonatomic) IBOutlet UITextField *devNewKeyField;
@property (weak, nonatomic) IBOutlet UITextField *cardField;
@property (weak, nonatomic) IBOutlet UITextField *floorField;
@property (weak, nonatomic) IBOutlet UIPickerView *dirPickerView;

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initSubview];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self refreshSubview];
}

- (void)initSubview
{
    UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(save:)];
    self.navigationItem.rightBarButtonItem = right;
}

- (void)refreshSubview
{
    self.devKeyField.text = self.devKey;
    self.devNewKeyField.text = self.devNewKey;
    self.cardField.text = self.card;
    self.floorField.text = [NSString stringWithFormat:@"%d", self.floor];
    [self.dirPickerView selectRow:self.dir inComponent:0 animated:YES];
}

- (void)save:(id)sender
{
    if (self.callback)
    {
        self.devKey = self.devKeyField.text;
        self.devNewKey = self.devNewKeyField.text;
        self.card = self.cardField.text;
        self.floor = self.floorField.text.intValue;
        self.dir = [self.dirPickerView selectedRowInComponent:0];
        
        NSArray *params = @[self.devKey, self.devNewKey, self.card, @(self.floor), @(self.dir)];
        self.callback(params);
    }
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UIPickerViewDataSource
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return 2;
}

#pragma mark - UIPickerViewDelegate
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (row == 0)
    {
        return @"上";
    }
    else
    {
        return @"下";
    }
}

/*
- (void)dealloc
{
    NSLog(@"%@ %s", NSStringFromClass(self.class), __FUNCTION__);
}
 */

@end
