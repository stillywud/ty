//
//  SettingViewController.h
//  RfmAccessControl-iOS-Demo
//
//  Created by yeyufeng on 2017/3/24.
//  Copyright © 2017年 REFORMER. All rights reserved.
//

#import <UIKit/UIKit.h>
//引入立方设备SDK头文件
#import <RfmAccessControl/RfmAccessControl.h>

typedef void (^SettingVcCallback)(NSArray *params);

@interface SettingViewController : UIViewController

@property (nonatomic, copy) NSString *devKey;
@property (nonatomic, copy) NSString *devNewKey;
@property (nonatomic, copy) NSString *card;
@property (nonatomic, assign) int8_t floor;
@property (nonatomic, assign) HallBtnDir dir;             //呼梯方向

@property (nonatomic, copy) SettingVcCallback callback;

@end
