//
//  ViewController.m
//  RfmAccessControl-iOS-Demo
//
//  Created by yeyufeng on 2017/3/24.
//  Copyright © 2017年 REFORMER. All rights reserved.
//

#import "ViewController.h"
#import "SettingViewController.h"

#pragma mark - 设备密码（每个设备的密码都可能不同，设备密码不是开门密码，设备密码参与开门密码的运算）
#define kDeviceKey                  @"31313131313131313131313131313131"
#define kDeviceNewKey               @"31313131313131313131313131313100"
//
#define kCardCode                   @"013612345678"
#define kShowTimeLong               2
#define kShowTime                   2

typedef NS_ENUM(NSInteger, Task)
{
    TaskOpenDoor,
    TaskCardTrans,
    TaskTest,
    TaskSetDevKey,
    TaskOpenElevator,
    TaskOpenHallBtn
};

@interface ViewController () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>

@property (nonatomic, strong) NSArray *devices;
@property (nonatomic, assign) Task task;

@property (nonatomic, copy) NSString *devKey;           //设备密码(设备密码不是开门密码，但参与开门密码运算，开门密码是动态的)
@property (nonatomic, copy) NSString *devNewKey;
@property (nonatomic, copy) NSString *card;             //卡号(手机号)，必须是12字节可转换为Hex的字符串
@property (nonatomic, assign) int8_t floor;             //楼层（梯控输出口编号）
@property (nonatomic, assign) HallBtnDir dir;           //呼梯方向

@property (nonatomic, strong) NSArray *sections;

@end

@implementation ViewController

#pragma mark - 视图
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //
    [self initDemoData];
    [self initSubview];
}

- (void)initDemoData
{
    // UI
    NSArray *titles1 = @[@"初始化SDK(不要多次调用)", @"查附近设备",  @"设置设备密码"];
    NSArray *titles2 = @[@"开门", @"发送卡号", @"测试设备"];
    NSArray *titles3 = @[@"梯控", @"呼梯"];
    self.sections = @[titles1, titles2, titles3];
    
    //
    self.devKey = kDeviceKey;
    self.devNewKey = kDeviceNewKey;
    self.card = kCardCode;
    self.floor = 0;
    self.dir = HallBtnDirUp;
}

- (void)initSubview
{
    self.messageLabel.text = @"";
    self.tableView.tableFooterView = [[UIView alloc] init];
}

#pragma mark UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    
    if (section == 0)
    {
        switch (row) {
            case 0:     //初始化SDK
                [self setupSDK];
                break;
            case 1:     //查附近设备
                [self discoveredDevices];
                break;
            case 2:     //设置设备密码
                [self setDeviceKey];
                break;
            default:
                break;
        }
    }
    else if (section == 1)
    {
        switch (row) {
            case 0:     //开门
                [self openDoor];
                break;
            case 1:     //发送卡号
                [self cardTrans];
                break;
            case 2:     //测试设备
                [self testDev];
                break;
            default:
                break;
        }
    }
    else
    {
        switch (row) {
            case 0:     //梯控
                [self openElevator];
                break;
            case 1:     //呼梯
                [self openHallBtn];
                break;
            default:
                break;
        }
    }
}

#pragma mark UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *titles = self.sections[section];
    return titles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    NSArray *titles = self.sections[section];
    cell.textLabel.text = titles[row];
    
    return cell;
}

#pragma mark - SDK相关
//初始化SDK, 不使用白名单
- (BOOL)setupSDK1
{
    return [[RfmSession sharedManager] setupWithWhitelist:nil delegate:self];
}

//未调用，初始化SDK, 使用白名单过滤，SDK底层对不在白名单中的设备不进行处理
- (BOOL)setupSDK2
{
    //白名单
    NSArray *macStrings = @[@"011122334455667788", @"011122334455667789"];
    NSMutableArray *macs = [[NSMutableArray alloc] init];
    for (NSString *macString in macStrings)
    {
        [macs addObject:[macString stringToHexData]];
    }
    return [[RfmSession sharedManager] setupWithWhitelist:macs delegate:self];
}

//初始化SDK
- (void)setupSDK
{
    if ([self setupSDK1])
    {
        [self showMessage:@"SDK初始化完成" time:kShowTime];
    }
    else
    {
        [self showMessage:@"参数有误" time:kShowTime];
    }
}

//检查状态
- (BOOL)basicStateCheck
{
    CBManagerState state = [RfmSession sharedManager].cbState;
    BOOL stateOK = NO;
    //
    if (state == CBCentralManagerStatePoweredOff)
    {
        [self showMessage:@"蓝牙开关未开启" time:kShowTime];
    }
    else if (state == CBCentralManagerStateUnsupported)
    {
        [self showMessage:@"手机不支持" time:kShowTime];
    }
    else if (state == CBCentralManagerStateUnauthorized)
    {
        [self showMessage:@"用户未授权" time:kShowTime];
    }
    else if (state != CBCentralManagerStatePoweredOn)
    {
        [self showMessage:@"蓝牙未就绪" time:kShowTime];
    }
    else
    {
        stateOK = YES;
    }
    return stateOK;
}

//查询已发现的门禁模块，如果使用了白名单，白名单之外的设备不会给出
- (void)discoveredDevices
{
    NSArray *simpleDevices = [[RfmSession sharedManager] discoveredDevices];
    //
    NSString *string = [[NSString alloc] initWithFormat:@"附近有 %d 个设备，详见调试信息", (int)simpleDevices.count];
    [self showMessage:string time:kShowTime];
    
    for (RfmSimpleDevice *device in simpleDevices)
    {
        NSLog(@"mac:%@ %@ rssi:%d", [device.mac dataToHexString], device.name, (int)device.rssi);
    }
}

//设置设备密码
- (void)setDeviceKey
{
    if ([self basicStateCheck])
    {
        _devices = [[RfmSession sharedManager] discoveredDevices];
        if (_devices.count > 0)
        {
            _task = TaskSetDevKey;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"设置设备密码" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:nil];
            for (RfmSimpleDevice *device in _devices)
            {
                [actionSheet addButtonWithTitle:[device.mac dataToHexString]];
            }
            actionSheet.delegate = self;
            [actionSheet showInView:self.view];
        }
        else
        {
            [self showMessage:@"未搜索到设备" time:kShowTimeLong];
        }
    }
}

//开门
- (void)openDoor
{
    if ([self basicStateCheck])
    {
        _devices = [[RfmSession sharedManager] discoveredDevices];
        if (_devices.count > 0)
        {
            _task = TaskOpenDoor;
            /*
             if (_devices.count == 1)
             {
             //演示，只有一扇门，直接开门，保持输出6秒
             RfmSimpleDevice *device = _devices[0];
             if ([[RfmSession sharedManager] openDoorWithMac:device.mac outputActiveTime:60])
             {
             [self showMessage:@"认证中..." time:kShowTimeLong];
             }
             }
             else
             */
            {
                UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"选择要开启的门" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:nil];
                for (RfmSimpleDevice *device in _devices)
                {
                    [actionSheet addButtonWithTitle:[device.mac dataToHexString]];
                }
                actionSheet.delegate = self;
                [actionSheet showInView:self.view];
            }
        }
        else
        {
            [self showMessage:@"未搜索到设备" time:kShowTimeLong];
        }
    }
}

//卡号传输
- (void)cardTrans
{
    if ([self basicStateCheck])
    {
        _devices = [[RfmSession sharedManager] discoveredDevices];
        if (_devices.count > 0)
        {
            _task = TaskCardTrans;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"卡号传输" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:nil];
            for (RfmSimpleDevice *device in _devices)
            {
                [actionSheet addButtonWithTitle:[device.mac dataToHexString]];
            }
            actionSheet.delegate = self;
            [actionSheet showInView:self.view];
        }
        else
        {
            [self showMessage:@"未搜索到设备" time:kShowTimeLong];
        }
    }
}

//测试设备
- (void)testDev
{
    if ([self basicStateCheck])
    {
        _devices = [[RfmSession sharedManager] discoveredDevices];
        if (_devices.count > 0)
        {
            _task = TaskTest;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"测试设备" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:nil];
            for (RfmSimpleDevice *device in _devices)
            {
                [actionSheet addButtonWithTitle:[device.mac dataToHexString]];
            }
            actionSheet.delegate = self;
            [actionSheet showInView:self.view];
        }
        else
        {
            [self showMessage:@"未搜索到设备" time:kShowTimeLong];
        }
    }
}

//梯控
- (void)openElevator
{
    if ([self basicStateCheck])
    {
        _devices = [[RfmSession sharedManager] discoveredDevices];
        if (_devices.count > 0)
        {
            _task = TaskOpenElevator;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"梯控" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:nil];
            for (RfmSimpleDevice *device in _devices)
            {
                [actionSheet addButtonWithTitle:[device.mac dataToHexString]];
            }
            actionSheet.delegate = self;
            [actionSheet showInView:self.view];
        }
        else
        {
            [self showMessage:@"未搜索到设备" time:kShowTimeLong];
        }
    }
}

//呼梯
- (void)openHallBtn
{
    if ([self basicStateCheck])
    {
        _devices = [[RfmSession sharedManager] discoveredDevices];
        if (_devices.count > 0)
        {
            _task = TaskOpenHallBtn;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"呼梯" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:nil];
            for (RfmSimpleDevice *device in _devices)
            {
                [actionSheet addButtonWithTitle:[device.mac dataToHexString]];
            }
            actionSheet.delegate = self;
            [actionSheet showInView:self.view];
        }
        else
        {
            [self showMessage:@"未搜索到设备" time:kShowTimeLong];
        }
    }
}

- (IBAction)action7:(id)sender
{
    /*
     //交换新旧密码
     NSString *tmp = self.deviceKeyField.text;
     self.deviceKeyField.text = self.deviceNewKeyField.text;
     self.deviceNewKeyField.text = tmp;
     */
}

#pragma mark UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex > 0)
    {
        RfmSimpleDevice *device = _devices[buttonIndex-1];
        //
        switch (_task) {
            case TaskOpenDoor:      //开门，开门信号保持输出6秒
            {
                RfmActionError error = [[RfmSession sharedManager] openDoorCheckedWithMac:device.mac deviceKey:self.devKey outputActiveTime:60];
                if (error == RfmActionErrorNone)
                {
                    [self showMessage:@"认证中..." time:kShowTimeLong];
                }
                else if (error == RfmActionErrorParam)
                {
                    [self showMessage:@"输入参数有误" time:kShowTimeLong];
                }
                else if (error == RfmActionErrorNoDevice)
                {
                    [self showMessage:@"指定设备不再范围内" time:kShowTimeLong];
                }
                else if (error == RfmActionErrorPoweredOff)
                {
                    [self showMessage:@"蓝牙开关未开启" time:kShowTimeLong];
                }
                else if (error == RfmActionErrorUnauthorized)
                {
                    [self showMessage:@"用户未授权" time:kShowTimeLong];
                }
                else if (error == RfmActionErrorBusy)
                {
                    [self showMessage:@"操作忙" time:kShowTimeLong];
                }
                else if (error == RfmActionErrorOther)
                {
                    [self showMessage:@"其他异常" time:kShowTimeLong];
                }
                break;
            }
            case TaskCardTrans:     //卡号传输
            {
                RfmActionError error = [[RfmSession sharedManager] sendCardWithMac:device.mac deviceKey:self.devKey card:self.card];
                if (error == RfmActionErrorNone)
                {
                    [self showMessage:@"传输中" time:kShowTimeLong];
                }
                else    //具体参考开门的返回，这里不处理细节
                {
                    [self showMessage:@"操作失败" time:kShowTimeLong];
                }
                break;
            }
            case TaskTest:      //测试设备
            {
                RfmActionError error = [[RfmSession sharedManager] testDevice:device.mac deviceKey:self.devKey];
                if (error == RfmActionErrorNone)
                {
                    [self showMessage:@"测试中" time:kShowTimeLong];
                }
                else    //具体参考开门的返回，这里不处理细节
                {
                    [self showMessage:@"操作失败" time:kShowTimeLong];
                }
                break;
            }
            case TaskSetDevKey:     //设置设备密码
            {
                RfmActionError error = [[RfmSession sharedManager] setDeviceKey:device.mac newKey:self.devNewKey];
                if (error == RfmActionErrorNone)
                {
                    [self showMessage:@"进行中" time:kShowTimeLong];
                }
                else    //具体参考开门的返回，这里不处理细节
                {
                    [self showMessage:@"操作失败" time:kShowTimeLong];
                }
                break;
            }
            case TaskOpenElevator:      //梯控
            {
                RfmActionError error = [[RfmSession sharedManager] openElevator:device.mac deviceKey:self.devKey code:self.card floor:self.floor];
                if (error == RfmActionErrorNone)
                {
                    [self showMessage:@"认证中..." time:kShowTimeLong];
                }
                else    //具体参考开门的返回，这里不处理细节
                {
                    [self showMessage:@"操作失败" time:kShowTimeLong];
                }
                break;
            }
            case TaskOpenHallBtn:       //呼梯
            {
                RfmActionError error = [[RfmSession sharedManager] openHallBtn:device.mac deviceKey:self.devKey code:self.card dir:self.dir];
                if (error == RfmActionErrorNone)
                {
                    [self showMessage:@"认证中..." time:kShowTimeLong];
                }
                else    //具体参考开门的返回，这里不处理细节
                {
                    [self showMessage:@"操作失败" time:kShowTimeLong];
                }
                break;
            }
            default:
                break;
        }
    }
}

#pragma mark RfmSessionDelegate
///门禁系统会话完成事件回调
- (void)rfmSessionDidFinishedEvent:(RfmSessionEvent)event mac:(NSData *)mac error:(RfmSessionError)error extra:(id)extra
{
    NSInteger result = 1;
    NSString *message;
    //
    if (event == RfmSessionEventOpenDoor || event == RfmSessionEventElevator || event == RfmSessionEventHallBtn)   //开门
    {
        switch (error)
        {
            case RfmSessionErrorNone:
            {
                result = 0;
                message = @"操作成功";
                break;
            }
            case RfmSessionErrorNoDevice:
            {
                message = @"未搜索到设备";
                break;
            }
            case RfmSessionErrorDeviceInteraction:
            {
                message = @"设备通讯异常";
                break;
            }
            case RfmSessionErrorDeviceTimeOut:
            {
                message = @"设备应答超时";
                break;
            }
            case RfmSessionErrorDeviceRespError:    //蓝牙控制器拒绝请求，通常就是动态开门密码错误
            {
                int devResp = [extra intValue];
                if (devResp == 0x01 || devResp == 0x10)
                {
                    message = @"操作失败，密码错误";
                }
                else if (devResp == 0x04)
                {
                    message = @"设备不支持该操作";
                }
                else if (devResp <= 0x0f)
                {
                    message = @"操作失败";
                }
                else
                {
                    message = [NSString stringWithFormat:@"设备拒绝，代码0x%x", devResp];
                }
                break;
            }
            default:
                break;
        }
        //
        [self showMessage:message time:kShowTime];
    }
    else if (event == RfmSessionEventCard)   //卡号传输
    {
        switch (error)
        {
            case RfmSessionErrorNone:
            {
                result = 0;
                message = @"卡号传输成功";
                break;
            }
            case RfmSessionErrorNoDevice:
            {
                message = @"未搜索到设备";
                break;
            }
            case RfmSessionErrorDeviceInteraction:
            {
                message = @"蓝牙通讯异常";
                break;
            }
            case RfmSessionErrorDeviceTimeOut:
            {
                message = @"蓝牙通讯超时";
                break;
            }
            case RfmSessionErrorDeviceRespError:
            {
                message = @"设备返回错误";
                break;
            }
            default:
                break;
        }
        //
        [self showMessage:message time:kShowTime];
    }
    else if (event == RfmSessionEventTestDevice)   //测试设备
    {
        switch (error)
        {
            case RfmSessionErrorNone:
            {
                result = 0;
                message = @"测试成功";
                break;
            }
            case RfmSessionErrorNoDevice:
            {
                message = @"未搜索到设备";
                break;
            }
            case RfmSessionErrorDeviceInteraction:
            {
                message = @"蓝牙通讯异常";
                break;
            }
            case RfmSessionErrorDeviceTimeOut:
            {
                message = @"蓝牙通讯超时";
                break;
            }
            case RfmSessionErrorDeviceRespError:
            {
                message = @"设备返回错误";
                break;
            }
            default:
                break;
        }
        //
        [self showMessage:message time:kShowTime];
    }
    else if (event == RfmSessionEventSetDeviceKey)   //设置设备密码
    {
        switch (error)
        {
            case RfmSessionErrorNone:
            {
                result = 0;
                message = @"设置成功";
                break;
            }
            case RfmSessionErrorDeviceRespError:
            {
                message = @"设备拒绝请求";
                break;
            }
            default:
            {
                message = @"设置失败";
                break;
            }
        }
        //
        [self showMessage:message time:kShowTime];
    }
}

///已发现的门禁模块列表发生变化
- (void)rfmSessionDetectedDevicesChanged:(NSArray *)devices
{
    /*
     NSLog(@"rfmSessionDetectedDevicesChanged");
     for (RfmSimpleDevice *simpleDevice in devices)
     {
     NSLog(@"%@，%@，%d", simpleDevice.mac, simpleDevice.name, (int)simpleDevice.rssi);
     }
     */
}

#pragma mark - 简单信息提示
- (void)showMessage:(NSString *)message time:(NSTimeInterval)time
{
    NSLog(@"%@", message);
    self.messageLabel.text = message;
    //
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(dismissMessage) object:nil];
    [self performSelector:@selector(dismissMessage) withObject:nil afterDelay:time];
}

- (void)dismissMessage
{
    self.messageLabel.text = @"";
}

#pragma mark - UITextFiledDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isFirstResponder])
    {
        [textField resignFirstResponder];
    }
    return YES;
}

#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.destinationViewController isKindOfClass:[SettingViewController class]]) {
        SettingViewController *vc = (SettingViewController *)segue.destinationViewController;
        vc.devKey = self.devKey;
        vc.devNewKey = self.devNewKey;
        vc.card = self.card;
        vc.floor = self.floor;
        vc.dir = self.dir;
        
        vc.callback = ^(NSArray *params) {
            self.devKey = params[0];
            self.devNewKey = params[1];
            self.card = params[2];
            self.floor = [params[3] intValue];
            self.dir = [params[4] intValue];
        };
    }
}

@end
