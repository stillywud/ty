<template>
    <div>
        <span @click="open">3333</span>
        <a-modal 
        v-model="visible" 
        @cancel="cancelAModel"
        :destroyOnClose="destroyOnClose"
        title="表单设计器" 
        width="100%" 
        :footer="null"
        class="mtt-form-making-model fullscreen">
            <div class="mtt-form-making-con" style="height:calc(100vh - 57px);border: 1px solid transparent;">
                <!-- <div> -->
                    <a-steps :current="current" class="mtt-steps-header">
                        <a-step v-for="item in steps" :key="item.title" :title="item.title" />
                    </a-steps>
                    <div class="mtt-steps-content" style="height:calc(100vh - 200px)">
                        <!-- <keep-alive> -->
                            <one v-show="current === 0" ref="one"/>
                            <two v-show="current === 1" ref="two"/>
                            <three v-show="current === 2" ref="three"/>
                        <!-- </keep-alive> -->
                    </div>
                    <div class="mtt-steps-action">
                        <a-button v-if="current > 0" @click="prev">
                            上一步
                        </a-button>
                        <a-button v-if="current < steps.length - 1" type="primary" style="margin-left: 8px" @click="next">
                            下一步
                        </a-button>
                        <a-button @click="handlePreview" v-if="current == steps.length - 1" style="margin-left: 8px" >
                            预览
                        </a-button>
                        <a-button v-if="current == steps.length - 1" style="margin-left: 8px" >
                            保存
                        </a-button>
                    </div>
                <!-- </div> -->
                <!-- <a-layout class="mtt-form-making-wrapper">
                    <a-layout>
                        <a-layout-sider :width="250" style="background:#fff">
                            <div class="components-list">
                                <template v-if="basicFields.length">
                                    <draggable tag="ul" :list="basicComponents" 
                                    v-bind="{group:{ name:'people', pull:'clone',put:false},sort:false, ghostClass: 'ghost'}"
                                    @end="handleMoveEnd"
                                    @start="handleMoveStart"
                                    :move="handleMove"
                                    >
                                    <template v-for="(item, index) in basicComponents">
                                        <li 
                                            v-if="basicFields.indexOf(item.type)>=0" 
                                            class="form-edit-widget-label" 
                                            :key="index">
                                            <a>
                                                <span>{{item.name}}</span>
                                            </a>
                                        </li>
                                    </template>
                                    </draggable>
                                </template>
                            </div>
                        </a-layout-sider>
                        <a-layout-content>
                            <a-layout style="height:100%">
                                <a-layout-content class="widget-con">
                                    <widget-form 
                                        v-if="!resetJson" 
                                        ref="widgetForm" 
                                        :data="widgetForm" 
                                        :select.sync="widgetFormSelect" />
                                </a-layout-content>
                            </a-layout>
                        </a-layout-content>
                        <a-layout-sider :width="300" style="background:#fff" class="widget-config-container">
                            <a-layout-header height="45px" style="background:#fff">
                                <div class="config-tab">字段属性</div>
                            </a-layout-header>
                            <a-layout-content class="config-content">
                                <widget-config v-show="configTab=='widget'" :data="widgetFormSelect"></widget-config>
                            </a-layout-content>
                        </a-layout-sider>
                    </a-layout>
                    <a-layout-footer style="padding:0 10px">
                        <span @click="handleUpload">导入</span>
                        <span @click="handleGenerateJson">导出JSON</span>
                    </a-layout-footer>
                </a-layout> -->
            </div>
        </a-modal>
    </div>
</template>
<script>
// import draggable from 'vuedraggable'
// import WidgetForm from './WidgetForm.vue'
// import WidgetConfig from './WidgetConfig'
// import FormConfig from './FormConfig'
// import {basicComponents} from './config.js'

import One from './one.vue'
import Two from './gragg/index.vue'
import Three from './three.vue'
export default {
    name:"df-index",
    data(){
        return{
            current: 2,
            steps: [
                {
                    title: '第一步',
                },
                {
                    title: '第二步',
                },
                {
                    title: '第三部',
                },
            ],
            includeA:['One','Two','Three'],
            excludeA:[''],
            destroyOnClose:false,
            visible:true,
        }
    },
    components:{
        One,
        Two,
        Three
        // draggable,
        // WidgetForm,
        // WidgetConfig,
        // FormConfig
    },
    mounted(){
        // if (this.widgetForm.list.length> 0) {
        //     this.widgetFormSelect = this.widgetForm.list[0]
        // }
        // this.$nextTick(()=>{
        //     console.log(this.$refs.componentA.dataone)
        // })
        
    },
    methods:{
        next() {
            
            // if(this.current === 1){
            //     console.log(this.$refs.one.$data)
            // }else if(this.current === 2){
            //     console.log(this.$refs.two.$data)
            // }
            console.log(this.$refs.two.$data,this.current )
            if(this.current === 1 && !this.$refs.two.$data.widgetForm.list.length){
                return this.$message.warning('请制作模版')
            }
            this.current++;
        },
        prev() {
            this.current--;
        },
        cancelAModel(){
            this.visible = false;
            this.destroyOnClose=true;
            this.current = 0;
        },
        open(){
            this.visible = true;
        },
        handleUpload(){
            this.widgetForm = {
                "list":[
                    {
                        "type":"tabs","name":"Tabs","hideTitle":false,"hideLabel":true,"isContainer":true,
                        "panes":[
                            {"key":1,"name":"Tab1","rowNum":1,"list":[]},
                            {"key":2,"name":"Tab2","rowNum":1,"list":[]}
                        ],
                        "options":{"width":"100%","activeName":1,"tabBarGutter":10,"type":"editable-card","position":"top","hidden":false},
                        "key":"1607827965000_97988"
                    }
                ],
                "config":{"labelWidth":100,"labelPosition":"right","size":"small"}
            }
        },
        handleConfigSelect: function(e) {
            this.configTab = e
        },
        handleMoveEnd: function() {},
        handleMoveStart: function(e) {e.oldIndex},
        handleMove: function() {return !0},
        handlePreview: function() {
            console.log(this.$refs)
        },
    }
}
</script>
<style lang="less">
.mtt-form-making-model{
    li, ul{
        list-style: none;
        margin: 0;
        padding: 0;
    }
    &.fullscreen{
        .ant-modal{
            top: 0;
            padding: 0;
            margin: 0;
            height: 100vh;
        }
        .ant-modal-body{
            padding: 12px;
        }
        .ant-modal-content{
            height: 100vh;
        }
        .ant-modal-body{
            // height: calc(100vh - 47px);
            padding: 0;
        }
    }
    .mtt-form-making-con{
        height: 100%;
    }
    .mtt-form-making-wrapper{
        height: 100%;
        .btn-bar{
            background: #fff;
            text-align: right;
        }
        .widget-con{
            padding: 0;
            position: relative;
            background: #fafafa;
        }
        .components-list {
            padding: 8px 0;
            width: 100%;
            height: 100%;
            .widget-cate {
                padding: 8px 12px;
                font-size: 13px;
            }
            ul {
                position: relative;
                overflow: hidden;
                padding: 0 10px 10px;
                margin: 0;
            }
            .form-edit-widget-label {
                font-size: 12px;
                display: block;
                width: 48%;
                line-height: 26px;
                position: relative;
                float: left;
                left: 0;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                margin: 1%;
                color: #333 !important;
                border: 1px solid #f4f6fc;
                & >a {
                    display: block;
                    cursor: move;
                    color: #333 !important;
                    background: #f4f6fc;
                    border: 1px solid #f4f6fc;
                    text-align: center;
                }
            }
        }
        .widget-config-container{
            .ant-btn-icon-danger{
                color: #f56c6c;
                border-radius: 100%;
            }
            .ant-layout-sider-children{
                    display: flex;
                flex-direction: column;
            }
            .config-content{
                flex:1;
                overflow: auto;
                padding: 10px;
            }
            .ant-layout-header{
                padding: 0;
            }
            .config-tab {
                height: 45px;
                line-height: 45px;
                display: inline-block;
                width: 145px;
                text-align: center;
                font-size: 14px;
                font-weight: 500;
                position: relative;
                cursor: pointer;
                &.active {
                    border-bottom: 2px solid #409eff;
                }
            }
        }
    }
    .mtt-steps-header{
        width: 800px;
        margin: 20px auto;
        
    }
    .mtt-steps-action{
        text-align: center;
    }
    
}
</style>