<template>
    <div>
        <a-input v-model="dataone" />

        
    </div>
</template>
<script>
export default {
    name:"one",
    data(){
        return{
            dataone:1111
        }
    }
}
</script>