<template>
    <div style="height:100%;overflow-y:auto">
        <div style="padding:10px">
            <a-steps :current="current" direction="vertical">
                <a-step v-for="it in list" :key="it.id">
                    <div slot="title">
                        <span>{{it.name}}</span>
                    </div>
                    <div slot="description">
                        <a-space>
                            <span>6666</span><span>777</span>
                            <a-icon type="edit" style="color:#1890ff" @click="editjiedian(it)"/><a-icon type="delete" style="color:#1890ff" @click="deljiedian(it)"/>
                        </a-space>
                    </div>
                    <a-icon slot="icon" type="user" />
                </a-step>
            </a-steps>
            <div style="text-align:center;margin-top:30px">
                <a-button @click="addjiedian">新增节点</a-button>
            </div>
        </div>
        
        <a-modal 
            v-model="visiDian" 
            :title="title"
            @ok="handleOk">
            <p>Some contents...</p>
            <p>Some contents...</p>
            <p>Some contents...</p>
        </a-modal>
    </div>
</template>
<script>
export default {
    name:"one",
    data(){
        return{
            current: undefined,
            visiDian:false,
            list:[],
            title:''
        }
    },
    methods:{
        addjiedian(){
            this.title="新增审批节点"
        },
        editjiedian(){
            this.title="编辑审批节点"
        },
        deljiedian(i){
            this.list = this.list.filter(item => {
                return item.id !== i.id
            })
        },
        handleOk(){
            // if(){}
            this.$message.warning('请勾选')
            this.visiDian = false;
        }
    }
}
</script>