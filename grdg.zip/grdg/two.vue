<template>
    <div>
        第2个
        <a-checkbox>
    Checkbox
  </a-checkbox>
    </div>
</template>
<script>
export default {
    name:"two",
    data(){
        return{
            nameb:'2222'
        }
    }
}
</script>