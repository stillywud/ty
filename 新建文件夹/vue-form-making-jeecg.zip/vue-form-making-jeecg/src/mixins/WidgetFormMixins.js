import { DeviceMixins } from '@/mixins/vuexMixins'

export default {
  mixins: [DeviceMixins],
  props: {},
  data() {
    return {}
  },
  watch: {},
  created() {
  },
  methods: {}
}