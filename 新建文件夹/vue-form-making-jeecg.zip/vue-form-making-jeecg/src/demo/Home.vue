<template>
  <jm-design-form ref="makingForm" upload preview generate-code generate-json>
    <template slot="action">
    </template>
  </jm-design-form>
</template>

<script>
export default {
  mounted () {
  }
}
</script>
