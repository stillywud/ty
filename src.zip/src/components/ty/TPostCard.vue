<template>
    
</template>
<script>
export default {
    name:"TPostCard",
    data(){

    }
}
</script>
<style lang="scss">

</style>